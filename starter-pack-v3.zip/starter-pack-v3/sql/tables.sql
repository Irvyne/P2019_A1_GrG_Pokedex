SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

CREATE TABLE IF NOT EXISTS `tweet` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL COMMENT 'refers to id in users table',
  `message` varchar(140) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

INSERT INTO `tweet` (`id`, `user_id`, `message`, `createdAt`) VALUES
(1, 1, 'I was having troubles with session variables working in some environments', NULL ),
(2, 1, ' It works properly when I used $_SESSION as pointers to arrays', NULL),
(3, 1, 'The solution is to do this after each time you do a', NULL),
(4, 1, 'I wrote a little page for controlling/manipulating the session', NULL),
(5, 1, 'Obviously, never use this on a production server, but I use it on my localhost to assist me', NULL),
(6, 1, 'Vive les poneys !', NULL),
(7, 1, 'Retweetez please !', NULL),
(8, 1, 'Une bicyclette est un véhicule terrestre, entrant dans la catégorie des cycles, composé de deux roues alignées (d''où le nom « bicyclette »)', NULL),
(9, 1, 'Tweeter c''est coooooool', NULL),
(10, 1, 'J''adore tweeter', NULL);

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(20) NOT NULL UNIQUE,
  `email` varchar(255) NOT NULL UNIQUE,
  `password` varchar(255) NOT NULL COMMENT 'encrypted passwords are better (eg. sha1)',
  `picture` varchar(255) NULL DEFAULT NULL COMMENT 'name of profile picture',
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

INSERT INTO `users` (`id`, `username`, `email`, `password`, `picture`, `createdAt`) VALUES
(1, 'user', 'user@gmail.com', '12dea96fec20593566ab75692c9949596833adc9', NULL, '2015-04-01 23:59:59');
