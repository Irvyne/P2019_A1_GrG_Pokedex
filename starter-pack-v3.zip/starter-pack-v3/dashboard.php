<?php

require 'bootstrap.php';

// TODO create tweet form validation

include 'template/dashboard.php';