<?php

require 'bootstrap.php';

// If user is already logged, redirect him to the dashboard
if (true === isSignedIn()) {
    header('Location: dashboard.php');
}

// If we send the form
if (!empty($_POST['signInForm'])) {
    $errors          = [];
    $usernameOrEmail = $_POST['usernameOrEmail'];
    $password        = $_POST['password'];

    if (empty($usernameOrEmail)) {
        $errors[] = 'All fields are mandatory!';
    }

    // TODO Check that username or email are not already linked to a user

    if (empty($errors)) {
        if (true === login($link, $usernameOrEmail, $password)) {
            header('Location: dashboard.php'); // Redirection
        } else {
            $errors[] = 'Bad credentials!';
        }
    }
}

$bodyClass = 'sign-in'; // Add a class to body (only 4 CSS)

include 'template/sign-in.php';
