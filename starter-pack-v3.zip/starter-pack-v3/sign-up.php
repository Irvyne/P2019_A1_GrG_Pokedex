<?php

require 'bootstrap.php';

// TODO create user form validation

$bodyClass = 'sign-up'; // Add a class to body (only 4 CSS)

include 'template/sign-up.php';
