<?php

$parameters = [
    'hostname' => 'localhost',
    'username' => 'root',
    'password' => 'toor', // MAC => 'root' | Windows => null
    'dbname'   => 'p2019_a1_grg_twitter',
    'port'     => null, // MAC => 8889 | Windows => null
];
