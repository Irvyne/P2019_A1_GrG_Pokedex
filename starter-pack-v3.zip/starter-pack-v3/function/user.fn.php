<?php

/**
 * Register a user and return true if user have been successfully created or false if an error occurred.
 *
 * @param mysqli $link
 * @param string $username
 * @param string $email
 * @param string $password
 */
function createUser($link, $username, $email, $password)
{
    // TODO
}

/**
 * Update profile picture, where $picture is $_FILES['picture'].
 *
 * @param mysqli  $link
 * @param integer $id
 * @param string  $picture
 *
 * @return boolean
 */
function updateProfilePicture($link, $id, $picture)
{
    // TODO
}

/**
 * Return true if username is available, false if not.
 *
 * @param mysqli  $link
 * @param integer $id
 *
 * @return boolean
 */
function isUsernameAvailable($link, $id)
{
    // TODO
}

/**
 * Return true if email is available, false if not.
 *
 * @param mysqli  $link
 * @param integer $id
 *
 * @return boolean
 */
function isEmailAvailable($link, $id)
{
    // TODO
}

/**
 * Pass a username and a password and return true if user exists, false if not.
 *
 * @param mysqli $link
 * @param string $emailOrUsername
 * @param string $password
 *
 * @return bool
 */
function login($link, $emailOrUsername, $password)
{
    // Protect values against => SQL Injection <= attack (http://www.w3schools.com/sql/sql_injection.asp 4 more details)
    $emailOrUsername = mysqli_real_escape_string($link, $emailOrUsername);
    $password        = mysqli_real_escape_string($link, $password);

    // Protect password (no password have to be saved into the database)
    $password = sha1($password);

    // SQL request to select only one user by its email or username and its password
    $sql = "SELECT id, username, email, createdAt, picture FROM users WHERE (email = '$emailOrUsername' OR username = '$emailOrUsername') AND password = '$password' LIMIT 1";

    // Execute the SQL request
    $query  = mysqli_query($link, $sql);

    // If the query have been successfully executed
    if (false !== $query) {
        // Get the result from request ($query)
        $result = mysqli_fetch_assoc($query);
        // If I have a result (so login is successful)
        if (false !== $query) {
            // We save in session every data to be retrieved without another SQL request
            $_SESSION['id']        = $result['id'];
            $_SESSION['username']  = $result['username'];
            $_SESSION['email']     = $result['email'];
            $_SESSION['createdAt'] = $result['createdAt'];
            $_SESSION['picture']   = $result['picture'];

            return true;
        }
    }

    return false;
}

/**
 * Return true or false, true if user is logged or false if user is not.
 *
 * @return bool
 */
function isSignedIn()
{
    // If PHP session is already started and user is logged, true is returned
    if (PHP_SESSION_ACTIVE === session_status() && !empty($_SESSION['id'])) {
        return true;
    }

    return false;
}
