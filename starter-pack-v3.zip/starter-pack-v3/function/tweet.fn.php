<?php

/**
 * Retrieve all tweets from DB.
 *
 * @return array
 */
function findAllTweets()
{
    // TODO (eg. SELECT)
}

/**
 * Retrieve one Tweet from DB by its id.
 *
 * @param mysqli  $link
 * @param integer $id
 *
 * @return array
 */
function findOneTweet($link, $id)
{
    // TODO (eg. SELECT)
}

/**
 * Is the Tweet is owned by a user.
 *
 * @param mysqli  $link
 * @param integer $id
 * @param integer $userId
 *
 * @return boolean
 */
function isTweetOwner($link, $id, $userId)
{
    // TODO (eg. SELECT)
}

/**
 * Create a Tweet.
 *
 * @param mysqli  $link
 * @param integer $userId
 * @param string  $message
 *
 * @return boolean
 */
function createTweet($link, $userId, $message)
{
    // TODO (eg. INSERT INTO)
}

/**
 * Update a Tweet by its id.
 *
 * @param mysqli  $link
 * @param integer $id
 * @param string  $message
 *
 * @return boolean
 */
function updateTweet($link, $id, $message)
{
    // TODO (eg. UPDATE)
}

/**
 * Remove a Tweet by its id.
 *
 * @param mysqli  $link
 * @param integer $id
 *
 * @return boolean
 */
function removeTweet($link, $id)
{
    // TODO (eg. DELETE)
}
