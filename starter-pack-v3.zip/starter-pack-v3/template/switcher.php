<?php include '_header.php'; ?>

<div id="sign-box" class="sign-box col-xs-12 col-sm-12 col-md-4 col-lg-4 midway-horizontal midway-vertical fadeInDown animated">
    <h1 class="text-center">
        <span class="glyphicon glyphicon-retweet"></span> Tiny Twitter!
    </h1>

    <a class="btn btn-default btn-sign btn-sign-in" href="sign-in.php">Sign In</a>
    <a class="btn btn-default btn-sign btn-sign-up" href="sign-up.php">Sign up</a>
</div>

<?php include '_footer.php'; ?>