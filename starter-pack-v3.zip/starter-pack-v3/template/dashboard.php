<?php include '_header.php'; ?>

<header id="header" class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
    <div class="container">
        <h1 class="col-xs-12 col-sm-5 col-md-4 col-lg-4 text-center animated fadeInLeftBig">Tiny Twitter</h1>
        <div class="col-xs-12 col-sm-7 col-md-8 col-lg-8 animated fadeIn">
            <form action="" method="post" autocomplete="off">
                <input type="text" name="tweet" placeholder="Hey, tell us what's up..." maxlength="140" required>
                <input type="submit" name="tweetForm" value="Tweet it!">
            </form>
        </div>
    </div>
</header>
<main class="container">
    <aside class="col-xs-12 col-sm-5 col-md-4 col-lg-4">
        <div id="user-box" class="text-center animated fadeInLeft">
            <div class="content">
                <figure class="profile">
                    <img class="img-circle" src="<?php echo null !== $_SESSION['picture'] ? $_SESSION['picture'] : 'img/profile-default.png'; ?>" alt="">
                    <figcaption><?php echo $_SESSION['username']; ?></figcaption>
                </figure>
                <p class="datetime">member since: <time><?php echo $_SESSION['createdAt']; ?></time></p>
            </div>
            <a href="sign-out.php" class="logout">logout</a>
        </div>
    </aside>
    <section id="tweet-feed" class="col-xs-12 col-sm-7 col-md-8 col-lg-8">
        <h1><span class="glyphicon glyphicon-time"></span> Timeline</h1>
        <!-- TODO If error or success message, display it here -->
        <!-- TODO Display all tweets in php -->
        <article class="tweet animated fadeInDown">
            <figure class="profile col-xs-5 col-sm-4 col-md-3 col-lg-2">
                <img class="img-circle img-responsive" src="img/profile-default.png" alt="Test">
            </figure>
            <div class="col-xs-7 col-sm-8 col-md-9 col-lg-10">
                </h1>Irvyne</h1>
                <p class="content">I am an awesome tweet by Irvyne, check it out!</p>
            </div>
            <div class="actions animated fadeInRightBig">
                <a href="edit.php"><span class="glyphicon glyphicon-pencil"></span></a>
                <a href=""><span class="glyphicon glyphicon-trash"></span></a>
            </div>
            <time class="datetime small animated fadeInRightBig">
                <span class="glyphicon glyphicon-time"></span> 08/04/2013
            </time>
        </article>
        <article class="tweet animated fadeInDown">
            <figure class="profile col-xs-5 col-sm-4 col-md-3 col-lg-2">
                <img class="img-circle img-responsive" src="img/profile-default.png" alt="Test">
            </figure>
            <div class="col-xs-7 col-sm-8 col-md-9 col-lg-10">
                </h1>Irvyne</h1>
                <p class="content">I am an awesome tweet by Irvyne, check it out!</p>
            </div>
            <div class="actions animated fadeInRightBig">
                <a href="edit.php"><span class="glyphicon glyphicon-pencil"></span></a>
                <a href=""><span class="glyphicon glyphicon-trash"></span></a>
            </div>
            <time class="datetime small animated fadeInRightBig">
                <span class="glyphicon glyphicon-time"></span> 08/04/2013
            </time>
        </article>
    </section>
</main>

<?php include '_footer.php'; ?>