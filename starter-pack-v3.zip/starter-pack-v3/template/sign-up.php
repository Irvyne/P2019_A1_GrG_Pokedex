<?php include '_header.php'; ?>

<div id="sign-up" class="sign-box col-xs-12 col-sm-12 col-md-4 col-lg-4 midway-horizontal midway-vertical fadeInDown animated">
    <h1 class="text-center">
        <span class="glyphicon glyphicon-retweet"></span> Tiny Twitter - Sign Up!
    </h1>
    <!-- TODO display error or success message -->
    <form action="" method="post">
        <div class="form-group has-icon">
            <label class="sr-only" for="username">Username</label>
            <input type="text" class="form-control" id="username" name="username" placeholder="Username" required autofocus>
            <span class="form-control-icon glyphicon glyphicon-user"></span>
        </div>
        <div class="form-group has-icon">
            <label class="sr-only" for="email">Email</label>
            <input type="email" class="form-control" id="email" name="email" placeholder="Email" required>
            <span class="form-control-icon glyphicon glyphicon-apple"></span>
        </div>
        <div class="form-group has-icon">
            <label class="sr-only" for="password">Password</label>
            <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
            <span class="form-control-icon glyphicon glyphicon-lock"></span>
        </div>
        <input type="submit" class="btn btn-default btn-sign btn-sign-up" name="signUpForm" value="Sign Up">
    </form>
    <p id="sign-up-link" class="text-center small">Already have an account? <a href="sign-in.php">Sign In!</a></p>
</div>

<?php include '_footer.php'; ?>