    <!-- Load jQuery from Google CDN -->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <!-- Fallback to a locale version of jQuery if Google CDN is not available -->
    <script>window.jQuery || document.write('<script src="js/vendor/jquery-2.1.3.min.js"><\/script>')</script>
    <!-- Load Bootstrap from locale -->
	<script src="js/vendor/bootstrap.min.js"></script>
	<script src="js/vendor/midway.min.js"></script>
    <!-- Load my scripts -->
	<script src="js/main.js"></script>
</body>
</html>
