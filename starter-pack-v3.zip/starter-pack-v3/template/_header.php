<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>IIM Tiny Twitter</title>
    <meta name="description" content="A Tiny Twitter">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="favicon.png">
    <link rel="apple-touch-icon" type="image/png"  href="apple-touch-icon.png">
    <!-- Bootstrap CSS (contains normalize library) -->
    <link rel="stylesheet" href="css/vendor/bootstrap.css">
    <link rel="stylesheet" href="css/vendor/animate.css">
    <!-- Add my CSS -->
    <link rel="stylesheet" href="css/main.css">
    <!-- Modernizr to support old browsers and support some HTML5 capabilities -->
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>
</head>
<body<?php echo !empty($bodyClass) ? ' class="'.$bodyClass.'"' : null; ?>>
    <!--[if lt IE 8]>
        <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->
