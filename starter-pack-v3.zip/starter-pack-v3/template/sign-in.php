<?php include '_header.php'; ?>

<div id="sign-in" class="sign-box col-xs-12 col-sm-12 col-md-4 col-lg-4 midway-horizontal midway-vertical fadeInDown animated">
    <h1 class="text-center">
        <span class="glyphicon glyphicon-retweet"></span> Tiny Twitter - Sign In!
    </h1>
    <?php
    if (!empty($errors)) {
        echo '<div class="alert alert-danger alert-dismissible fade in" role="alert">';
            echo '<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>';
            foreach ($errors as $error) {
                echo '<p class="text-center">'.$error.'</p>';
            }
        echo '</div>';
    }
    ?>
    <form action="" method="post">
        <div class="form-group has-icon">
            <label class="sr-only" for="usernameOrEmail">Username or Email</label>
            <input type="text" class="form-control" id="usernameOrEmail" name="usernameOrEmail" placeholder="Username or Email" required autofocus>
            <span class="form-control-icon glyphicon glyphicon-user"></span>
        </div>
        <div class="form-group has-icon">
            <label class="sr-only" for="password">Password</label>
            <input type="password" class="form-control" id="password" name="password" placeholder="Password" required>
            <span class="form-control-icon glyphicon glyphicon-lock"></span>
        </div>
        <input type="submit" class="btn btn-default btn-sign btn-sign-in" name="signInForm" value="Sign in">
    </form>
    <p id="sign-up-link" class="text-center small">Don't have an account? <a href="sign-up.php">Sign up!</a></p>
</div>

<?php include '_footer.php'; ?>