<?php

require 'bootstrap.php';

// TODO edit tweet form validation

include 'template/edit.php';