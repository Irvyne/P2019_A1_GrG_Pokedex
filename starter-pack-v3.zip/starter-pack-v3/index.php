<?php

require 'bootstrap.php';

// TODO redirect user to dashboard if he is already signed in

$bodyClass = 'switcher'; // Add a class to body (only 4 CSS)

include 'template/switcher.php';
