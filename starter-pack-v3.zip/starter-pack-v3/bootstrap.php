<?php

// Start Session to have access to $_SESSION
session_start();

require 'config/parameters.php';
require 'function/user.fn.php';
require 'function/tweet.fn.php';

$link = mysqli_connect(
    $parameters['hostname'],
    $parameters['username'],
    $parameters['password'],
    $parameters['dbname'],
    $parameters['port']
);
